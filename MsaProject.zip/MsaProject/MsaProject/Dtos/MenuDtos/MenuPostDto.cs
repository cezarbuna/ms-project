﻿namespace MsaProject.Dtos.MenuDtos
{
    public class MenuPostDto
    {
        public Guid RestaurantId { get; set; }
    }
}
