using MsaProject.Domain;

public class OwnerGetDo
{
    public ICollection<Restaurant> Restaurants { get; set; }
}