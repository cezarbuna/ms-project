﻿namespace MsaProject.Dtos.MenuItemDto
{
    public class MenuItemPostDto
    {
        public string Name { get; set; }
        public int Price { get; set; }
        public Guid MenuId { get; set; }
    }
}
