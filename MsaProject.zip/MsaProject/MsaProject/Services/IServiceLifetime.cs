﻿namespace MsaProject.Services
{
    public interface IServiceLifetime
    {
        Guid Guid { get; set; }
    }
}
