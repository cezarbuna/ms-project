﻿namespace MsaProject.Services
{
    public interface ISingletonService : IServiceLifetime
    {
    }
}
