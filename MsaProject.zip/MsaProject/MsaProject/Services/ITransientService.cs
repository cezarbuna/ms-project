﻿namespace MsaProject.Services
{
    public interface ITransientService : IServiceLifetime
    {
    }
}
