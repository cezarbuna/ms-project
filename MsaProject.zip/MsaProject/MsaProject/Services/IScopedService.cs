﻿namespace MsaProject.Services
{
    public interface IScopedService : IServiceLifetime
    {
    }
}
